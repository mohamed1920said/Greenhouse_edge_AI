#pragma once
#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>

/*
  GreenhouseDashboard
  - Header-only Arduino library for ESP32 WebServer dashboards.
  - Serves:
      GET  /     -> HTML dashboard (auto-refresh)
      GET  /api  -> JSON with sensors + actuators + optional temp state
  - No ArduinoJson dependency.
*/

class GreenhouseDashboard {
public:
  struct Actuator {
    const char* key;     // JSON key + HTML element id suffix. Example: "water_pump"
    const char* label;   // Label shown in UI. Example: "Water Pump"
    uint8_t pin;         // MCU pin connected to relay/actuator control
    bool activeLow;      // true for active-LOW relay boards (ON when pin reads LOW)
  };

  explicit GreenhouseDashboard(WebServer& server) : _server(server) {}

  void setSensors(float* tempC, float* hum, float* moist, float* lux) {
    _tempC = tempC;
    _hum   = hum;
    _moist = moist;
    _lux   = lux;
  }

  void setActuators(const Actuator* list, size_t count) {
    _acts = list;
    _actCount = count;
  }

  // Optional: configure a "temperature system" pair so the UI can show HEATING/COOLING/OFF
  // heaterFanPin = relay that enables heater+fan together
  // fanOnlyPin   = relay that enables fan only
  // (both are read-only here; your sketch still controls them)
  void setTemperatureSystemPins(int8_t heaterFanPin, int8_t fanOnlyPin) {
    _heaterFanPin = heaterFanPin;
    _fanOnlyPin   = fanOnlyPin;
  }

  void begin(const char* title = "ESP32 Dashboard") {
    _title = title ? title : "ESP32 Dashboard";
    _server.on("/", [this]() { this->handleRoot(); });
    _server.on("/api", [this]() { this->handleApi(); });
  }

private:
  WebServer& _server;

  const char* _title = "ESP32 Dashboard";

  float* _tempC = nullptr;
  float* _hum   = nullptr;
  float* _moist = nullptr;
  float* _lux   = nullptr;

  const Actuator* _acts = nullptr;
  size_t _actCount = 0;

  int8_t _heaterFanPin = -1;
  int8_t _fanOnlyPin   = -1;

  static float safeVal(float* p) { return p ? *p : 0.0f; }

  bool readPinOn(int pin, bool activeLow) const {
    int v = digitalRead(pin);
    return activeLow ? (v == LOW) : (v == HIGH);
  }

  bool readActuatorOn(const Actuator& a) const {
    return readPinOn(a.pin, a.activeLow);
  }

  // 0=disabled/unknown, 1=HEATING, 2=COOLING, 3=OFF, 4=CONFLICT
  int tempState() const {
    if (_heaterFanPin < 0 || _fanOnlyPin < 0) return 0;

    // Your project uses active-LOW relays. If you ever change, update here.
    bool heaterFanOn = readPinOn(_heaterFanPin, true);
    bool fanOnlyOn   = readPinOn(_fanOnlyPin, true);

    if (heaterFanOn && !fanOnlyOn) return 1; // heating
    if (!heaterFanOn && fanOnlyOn) return 2; // cooling
    if (!heaterFanOn && !fanOnlyOn) return 3; // off
    return 4; // conflict
  }

  void handleRoot() {
    String html;
    html.reserve(4800);

    html += F("<!doctype html><html><head><meta charset='utf-8'>");
    html += F("<meta name='viewport' content='width=device-width, initial-scale=1'>");
    html += F("<title>"); html += _title; html += F("</title>");

    html += F("<style>");
    html += F("body{font-family:Arial,sans-serif;margin:16px;}");
    html += F(".grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px;}");
    html += F(".card{border:1px solid #ddd;border-radius:12px;padding:12px;}");
    html += F(".title{font-weight:700;margin-bottom:10px;}");
    html += F(".row{display:flex;justify-content:space-between;align-items:center;margin:8px 0;}");
    html += F(".badge{padding:3px 10px;border-radius:999px;color:#fff;font-size:12px;}");
    html += F(".on{background:#1b7f3a;}.off{background:#777;}.warn{background:#b45309;}.bad{background:#b91c1c;}");
    html += F("small{color:#666;display:block;margin-bottom:12px;}");
    html += F("</style></head><body>");

    html += F("<h2>"); html += _title; html += F("</h2>");
    html += F("<small id='ip'>Device IP: --</small>");

    html += F("<div class='grid'>");

    // Sensors
    html += F("<div class='card'><div class='title'>Sensors</div>");
    html += F("<div class='row'><span>Temperature</span><span><b id='t'>--</b> &deg;C</span></div>");
    html += F("<div class='row'><span>Humidity</span><span><b id='h'>--</b> %</span></div>");
    html += F("<div class='row'><span>Soil Moisture</span><span><b id='m'>--</b> %</span></div>");
    html += F("<div class='row'><span>Light</span><span><b id='l'>--</b> lux</span></div>");
    html += F("</div>");

    // Actuators / System state
    html += F("<div class='card'><div class='title'>System</div>");

    // Temperature state row (only if configured)
    if (_heaterFanPin >= 0 && _fanOnlyPin >= 0) {
      html += F("<div class='row'><span>Temperature State</span><span id='temp_state' class='badge off'>--</span></div>");
    }

    html += F("<div class='title' style='margin-top:12px;'>Actuators</div>");

    if (_acts && _actCount > 0) {
      for (size_t i = 0; i < _actCount; i++) {
        html += F("<div class='row'><span>");
        html += _acts[i].label ? _acts[i].label : "(actuator)";
        html += F("</span><span id='a_");
        html += _acts[i].key ? _acts[i].key : "act";
        html += F("' class='badge off'>OFF</span></div>");
      }
    } else {
      html += F("<div class='row'><span>No actuators configured</span><span class='badge off'>--</span></div>");
    }

    html += F("</div>"); // card
    html += F("</div>"); // grid

    // JavaScript polling
    html += F("<script>");
    html += F("function setBadge(id,on){");
    html += F("const el=document.getElementById(id); if(!el) return;");
    html += F("el.textContent=on?'ON':'OFF'; el.className='badge '+(on?'on':'off');}");
    html += F("function setTempState(v){");
    html += F("const el=document.getElementById('temp_state'); if(!el) return;");
    html += F("let text='--', cls='off';");
    html += F("if(v===1){text='HEATING'; cls='warn';}");
    html += F("else if(v===2){text='COOLING'; cls='on';}");
    html += F("else if(v===3){text='OFF'; cls='off';}");
    html += F("else if(v===4){text='CONFLICT'; cls='bad';}");
    html += F("el.textContent=text; el.className='badge '+cls;}");
    html += F("async function refresh(){try{");
    html += F("const r=await fetch('/api',{cache:'no-store'}); const j=await r.json();");
    html += F("document.getElementById('t').textContent=(+j.tempC).toFixed(1);");
    html += F("document.getElementById('h').textContent=Math.round(+j.hum);");
    html += F("document.getElementById('m').textContent=Math.round(+j.moist);");
    html += F("document.getElementById('l').textContent=Math.round(+j.lux);");
    html += F("document.getElementById('ip').textContent='Device IP: '+j.ip;");
    html += F("if(typeof j.temp_state!=='undefined'){setTempState(j.temp_state);}");

    if (_acts && _actCount > 0) {
      for (size_t i = 0; i < _actCount; i++) {
        html += F("setBadge('a_");
        html += _acts[i].key ? _acts[i].key : "act";
        html += F("', j.act.");
        html += _acts[i].key ? _acts[i].key : "act";
        html += F(");");
      }
    }

    html += F("}catch(e){}}");
    html += F("setInterval(refresh,2000); refresh();");
    html += F("</script>");

    html += F("</body></html>");

    _server.send(200, "text/html", html);
  }

  void handleApi() {
    String json;
    json.reserve(650);

    json += "{";
    json += "\"tempC\":" + String(safeVal(_tempC), 2) + ",";
    json += "\"hum\":"   + String(safeVal(_hum), 2) + ",";
    json += "\"moist\":" + String(safeVal(_moist), 2) + ",";
    json += "\"lux\":"   + String(safeVal(_lux), 2) + ",";
    json += "\"ip\":\""  + WiFi.localIP().toString() + "\",";

    // Optional temperature state
    json += "\"temp_state\":" + String(tempState()) + ",";

    json += "\"act\":{";
    if (_acts && _actCount > 0) {
      for (size_t i = 0; i < _actCount; i++) {
        const auto& a = _acts[i];
        json += "\"";
        json += (a.key ? a.key : "act");
        json += "\":";
        json += (readActuatorOn(a) ? "true" : "false");
        if (i + 1 < _actCount) json += ",";
      }
    }
    json += "}}";

    _server.send(200, "application/json", json);
  }
};